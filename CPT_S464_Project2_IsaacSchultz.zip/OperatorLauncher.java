// Isaac Schultz 11583435
// Publisher launching is handled within this file.

public class OperatorLauncher {
	public static void main(String[] args) {
			Operator operator = new Operator(); //just makes a new operator and starts it since I didnt add cli arguments to operator class.
			operator.start();
	}
}
